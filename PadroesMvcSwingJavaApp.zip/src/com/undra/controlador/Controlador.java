/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.undra.controlador;

import edu.undra.modelo.Celula;
import edu.undra.modelo.Grade;
import edu.undra.util.ControllerHelper;
import edu.undra.view.MainForm;

/**
 *
 * @author alexandre
 */
public class Controlador {
    
    private Grade modelo;
    private MainForm mainForm;

    public Controlador(Grade modelo, MainForm mainForm) {
        this.modelo = modelo;
        this.mainForm = mainForm;
    }

    public Controlador(MainForm mainForm) {
        this.mainForm = mainForm;
    }

    public Grade getModelo() {
        return modelo;
    }

    public void setModelo(Grade modelo) {
        this.modelo = modelo;
    }

    public MainForm getMainForm() {
        return mainForm;
    }

    public void setMainForm(MainForm mainForm) {
        this.mainForm = mainForm;
    }

    public void atualizaView(Celula celula){
        
        ControllerHelper.atualizaMainView(celula, mainForm);
        
    }
    

}
