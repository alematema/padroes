/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.algoritmos;

import edu.undra.modelo.Celula;
import edu.undra.modelo.Grade;
import edu.undra.padroes.Padrao;
import edu.undra.util.pools.CelulaPool;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexandre
 */
public final class PadraoAleatorio implements Padrao {

    private int velocidade;
    private Grade grade;
    private Set<String> tentativas = new HashSet();

    public PadraoAleatorio() {
    }

    
    
    /**
     *
     * @param velocidade
     * @param grade
     */
    public PadraoAleatorio(int velocidade, Grade grade) {
        setVelocidadeExecucao(velocidade);
        setGrade(grade);
        tentativas = new HashSet();
    }

    @Override
    public void executar() {

        Celula celula = grade.getCelulaLivre();

        if (celula == null) {
            throw new RuntimeException("Não há célula livre na grade !!! " + grade);
        }

        tentativas.clear();


        while (!gradeTotalmenteOcupada()) {

            try {

                //gera um par de numeros (x,y) aleatorios : 0 <= x < linhas; 0 <= y < colunas
                int linha = (int) (Math.random() * (grade.getLinhas()));
                int coluna = (int) (Math.random() * (grade.getColunas()));

                //garante não setar duas vezes a mesma célula e que todas células serao setadas
                while (!tentativas.add(linha + "," + coluna)) {
                    linha = (int) (Math.random() * (grade.getLinhas()));
                    coluna = (int) (Math.random() * (grade.getColunas()));
                }

                grade.setCelula(linha, coluna, Celula.CELULA_OCUPADA);

                int sleepTime = 25 * ((int) ((float) 100 / velocidade));// sleeps at least 2500 ms(lowest speed) and at most 25 ms(highest speed) 

                if (velocidade == 100) {
                    sleepTime = 1;
                }

                Thread.sleep(sleepTime);

            } catch (InterruptedException ex) {
                Logger.getLogger(PadraoAleatorio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        grade.retornarCelulasAoPool();

    }

    private boolean gradeTotalmenteOcupada() {
        return tentativas.size() == grade.getLinhas() * grade.getColunas();
    }

    /**
     *
     * @return
     */
    @Override
    public int getVelocidadeExecucao() {
        return velocidade;
    }

    /**
     *
     * @param velocidade
     */
    @Override
    public void setVelocidadeExecucao(int velocidade) {

        if (velocidade <= 0) {
            throw new IllegalArgumentException("A velocidade não pode ser negativa ou zero !!!");
        } else if (velocidade > 100) {
            throw new IllegalArgumentException("A velocidade não pode ser superior a 100 !!!");
        }

        this.velocidade = velocidade;
    }

    /**
     *
     * @return
     */
    @Override
    public Grade getGrade() {
        return grade;
    }
    
    @Override
    public void setGrade(Grade grade) {
        if(grade==null)throw new IllegalArgumentException("A grade não pode ser null");
        this.grade = grade;
    }

    public static void main(String[] args) {

        CelulaPool pool = new CelulaPool(5000);

        Grade grade = new Grade(50, 50, pool);

        PadraoAleatorio padraoAleatorio = new PadraoAleatorio(100, grade);

        Thread t = new Thread(() -> {
            padraoAleatorio.executar();
        });
        t.start();

    }


}
