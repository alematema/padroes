/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.algoritmos;

import edu.undra.modelo.Celula;
import edu.undra.modelo.Grade;
import edu.undra.padroes.Padrao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexandre
 */
public final class PadraoCaracol implements Padrao {

    private int velocidade;
    private Grade grade;

    private Collection<Celula> caracol;

    Map<Integer, Collection<Celula>> indexMappedToCaracolMap = new HashMap();

    public PadraoCaracol() {
    }

    public PadraoCaracol(int velocidade, Grade grade) {
        setVelocidadeExecucao(velocidade);
        setGrade(grade);
    }

    @Override
    public void executar() {
        
        long init = System.nanoTime();
        double total;

        if (indexMappedToCaracolMap.containsKey(grade.getLinhas())) {

            caracol = indexMappedToCaracolMap.get(grade.getLinhas());
            
            caracol.forEach((c) -> {
                setCelula(c, Celula.CELULA_OCUPADA);
            });
            
            total = (System.nanoTime() - init) / 1e6;
            
            //System.err.println("CACHE : (KEY) " + grade.getLinhas() + " : havia caracol. Desenhado em   " + (total) + " ms");

        } else {

            caracol = new ArrayList();

            Celula celulaOndeEstou;

            celulaOndeEstou = grade.getCelula(grade.getLinhas() / 2, grade.getColunas() / 2);

            setCelula(celulaOndeEstou, Celula.CELULA_OCUPADA);

            int passos = 1;

            while (!celulaEstaForaDaGrade(celulaOndeEstou)) {

                celulaOndeEstou = virarADireita(celulaOndeEstou, passos);

                if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                } else {
                    break;
                }

                ++passos;
                ++passos;

                celulaOndeEstou = virarParaBaixo(celulaOndeEstou, passos);

                if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                } else {
                    break;
                }

                celulaOndeEstou = virarAEsquerda(celulaOndeEstou, passos);

                if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                } else {
                    break;
                }

                ++passos;
                ++passos;

                celulaOndeEstou = virarParaCima(celulaOndeEstou, passos);

                if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                } else {
                    break;
                }

            }

            try {
                Thread.sleep(250);
            } catch (InterruptedException ex) {
                Logger.getLogger(PadraoCaracol.class.getName()).log(Level.SEVERE, null, ex);
            }

            total = (System.nanoTime() - init) / 1e6;
            //System.err.println("no cache : ADD KEY " + grade.getLinhas() + " : nao havia caracol. Desenhado em  " + (total) + " ms");
            
            indexMappedToCaracolMap.put(grade.getLinhas(), caracol);
        }

        Collections.reverse((List)caracol);

        caracol.forEach((c) -> {
            setCelula(c, Celula.CELULA_DESOCUPADA);
        });

        //grade.retornarCelulasAoPool();

    }

    /**
     *
     * @return
     */
    @Override
    public int getVelocidadeExecucao() {
        return velocidade;
    }

    /**
     *
     * @param velocidade
     */
    @Override
    public void setVelocidadeExecucao(int velocidade) {

        if (velocidade <= 0) {
            throw new IllegalArgumentException("A velocidade não pode ser negativa ou zero !!!");
        } else if (velocidade > 100) {
            throw new IllegalArgumentException("A velocidade não pode ser superior a 100 !!!");
        }

        this.velocidade = velocidade;
    }

    /**
     *
     * @return
     */
    @Override
    public Grade getGrade() {
        return grade;
    }

    @Override
    public void setGrade(Grade grade) {
        if (grade == null) {
            throw new IllegalArgumentException("A grade não pode ser null");
        }
        if (grade.temDimensaoPar()) {
            throw new IllegalArgumentException("A grade não pode ter dimensao par. Apenas para dimensao impar está implementado o algorítmo");
        }

        this.grade = grade;
    }

    private boolean celulaEstaForaDaGrade(Celula celulaOndeEstou) {
        return grade.getCelula(celulaOndeEstou) == null;
    }

    private Celula virarADireita(Celula celulaOndeEstou, int passos) {

        for (int i = 1; i <= passos; i++) {
            celulaOndeEstou = grade.getCelula(celulaOndeEstou.getLinha(), celulaOndeEstou.getColuna() + 1);
            if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                setCelula(celulaOndeEstou, Celula.CELULA_OCUPADA);
            } else {
                break;
            }
        }

        return celulaOndeEstou;
    }

    private Celula virarParaBaixo(Celula celulaOndeEstou, int passos) {

        for (int i = 1; i <= passos; i++) {
            celulaOndeEstou = grade.getCelula(celulaOndeEstou.getLinha() + 1, celulaOndeEstou.getColuna());
            if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                setCelula(celulaOndeEstou, Celula.CELULA_OCUPADA);
            } else {
                break;
            }
        }

        return celulaOndeEstou;
    }

    private Celula virarAEsquerda(Celula celulaOndeEstou, int passos) {

        for (int i = 1; i <= passos; i++) {
            celulaOndeEstou = grade.getCelula(celulaOndeEstou.getLinha(), celulaOndeEstou.getColuna() - 1);
            if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                setCelula(celulaOndeEstou, Celula.CELULA_OCUPADA);
            } else {
                break;
            }
        }

        return celulaOndeEstou;
    }

    private Celula virarParaCima(Celula celulaOndeEstou, int passos) {

        for (int i = 1; i <= passos; i++) {
            celulaOndeEstou = grade.getCelula(celulaOndeEstou.getLinha() - 1, celulaOndeEstou.getColuna());
            if (!celulaEstaForaDaGrade(celulaOndeEstou)) {
                setCelula(celulaOndeEstou, Celula.CELULA_OCUPADA);
            } else {
                break;
            }
        }

        return celulaOndeEstou;
    }

    private void setCelula(Celula celula, Integer valor) {

        if (valor.equals(Celula.CELULA_DESOCUPADA)) {
            grade.setCelula(celula, Celula.CELULA_DESOCUPADA);
        } else {
            grade.setCelula(celula, Celula.CELULA_OCUPADA);
            if(!caracol.contains(celula))caracol.add(celula);
        }

        int sleepTime = 25 * ((int) ((float) 100 / velocidade));// sleeps at least 2500 ms(lowest speed) and at most 25 ms(highest speed) 

        if (velocidade == 100) {
            sleepTime = 1;
        }

        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException ex) {
            Logger.getLogger(PadraoCaracol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
