/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.algoritmos;

import edu.undra.modelo.Celula;
import edu.undra.modelo.Grade;
import edu.undra.padroes.Padrao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alexandre
 */
public final class PadraoExplosao implements Padrao {

    private int velocidade;
    private Grade grade;
    private Map<String, Collection<Celula>> dimensaoMappedToBordaMap = new HashMap();

    public PadraoExplosao() {
    }

    private final Collection<Celula> bordaPivo = new ArrayList();
    private Collection<Celula> borda = new ArrayList();

    public PadraoExplosao(int velocidade, Grade grade) {
        setVelocidadeExecucao(velocidade);
        setGrade(grade);
    }

    @Override
    public void executar() {

        int sleepTime = 1;

        int dimensaoGrade = getGrade().getLinhas();
        int i = dimensaoGrade;

        try {

            while (i >= 0) {

                getBorda(i).parallelStream().forEach(e -> {
                    getGrade().setCelula(e, Celula.CELULA_OCUPADA);
                });

                sleepTime = 25 * ((int) ((float) 100 / velocidade));// sleeps at least 2500 ms(lowest speed) and at most 25 ms(highest speed) 

                if (velocidade == 100) {
                    sleepTime = 1;
                }

                Thread.sleep(sleepTime);

                i -= 2;
            }

            if (dimensaoGrade % 2 == 1) {
                getGrade().setCelula((dimensaoGrade - 1) / 2, (dimensaoGrade - 1) / 2, Celula.CELULA_OCUPADA);
                Thread.sleep(sleepTime + 400);
            }

        } catch (InterruptedException ex) {
            Logger.getLogger(PadraoAleatorio.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            
            Thread.sleep(7*sleepTime);
            
            i = dimensaoGrade;
            while (i >= 0) {
                getBorda(i).parallelStream().forEach(e -> {
                    getGrade().setCelula(e, Celula.CELULA_DESOCUPADA);
                });
                i -= 2;
            }
            if (dimensaoGrade % 2 == 1) {
                getGrade().setCelula((dimensaoGrade - 1) / 2, (dimensaoGrade - 1) / 2, Celula.CELULA_OCUPADA);

            }
        } catch (Exception e) {
        }

        
    }

    @Override
    public void setVelocidadeExecucao(int velocidade) {
        if (velocidade <= 0) {
            throw new IllegalArgumentException("A velocidade não pode ser negativa ou zero !!!");
        } else if (velocidade > 100) {
            throw new IllegalArgumentException("A velocidade não pode ser superior a 100 !!!");
        }

        this.velocidade = velocidade;
    }

    @Override
    public void setGrade(Grade grade) {
        if (grade == null) {
            throw new IllegalArgumentException("A grade nao pode ser null");
        }
        this.grade = grade;
    }

    @Override
    public int getVelocidadeExecucao() {
        return velocidade;
    }

    @Override
    public Grade getGrade() {
        return grade;
    }

    private Collection<Celula> getBorda(int i) {

        long init = System.nanoTime();
        double total;
        int dimensão = getGrade().getLinhas();

        String key = Integer.toString(dimensão) + "," + Integer.toString(i);

        if (dimensaoMappedToBordaMap.containsKey(key)) {
            Collection<Celula> borda = dimensaoMappedToBordaMap.get(key);
            total = (System.nanoTime() - init) / 1e6;
            //System.err.println("CACHE : (KEY) " + key + " : havia borda para dimensao " + dimensão + " e para indice i " + i + " /borda recuperada em  " + (total) + " ms");

            return dimensaoMappedToBordaMap.get(key);
        }

        borda = new ArrayList();

        borda.addAll(getLinha(i, i, dimensão - i - 1));////pega a borda top da dimensao passada: (0,0) -> (0,dimensao-2)
        borda.addAll(getColuna(dimensão - i - 1, i, dimensão - i - 1));//pega a borda direita da dimensao  : (0,dimensao-1) -> (dimensao -2, dimensao-1)
        borda.addAll(getLinha(dimensão - i - 1, i, dimensão - i - 1));////pega a borda bottom da dimensao passada : (dimensao-1,0) -> (dimensao-1, dimensao-1)
        borda.addAll(getColuna(i, i, dimensão - i - 1));//pega a borda esquerda da dimensao  : (1,0) -> (dimensao-2,0)

        total = (System.nanoTime() - init) / 1e6;

        if (!dimensaoMappedToBordaMap.containsKey(key)) {
            //System.err.println("no cache : ADD KEY " + key + ", para dimensao " + dimensão + " e para indice i " + i + " /borda recuperada em  " + (total) + " ms");
        }

        dimensaoMappedToBordaMap.put(key, borda);

        return borda;

    }

    private Collection<? extends Celula> getLinha(int linha, int inicio, int fim) {

        bordaPivo.clear();

        for (int i = inicio; i <= fim; i++) {
            bordaPivo.add(getGrade().getCelula(linha, i));
        }

        return bordaPivo;
    }

    private Collection<? extends Celula> getColuna(int coluna, int inicio, int fim) {

        bordaPivo.clear();

        for (int i = inicio; i <= fim; i++) {
            bordaPivo.add(getGrade().getCelula(i, coluna));
        }

        return bordaPivo;
    }

}
