package edu.undra.modelo;

/**
 *
 * @author alexandre
 * @param <T>
 */
public class Celula<T> {
    
    public static Integer CELULA_OCUPADA = 1;

    /**
     *
     */
    public static Integer CELULA_DESOCUPADA = 0;

    private int linha;
    private int coluna;
    private T valor;

    public Celula() {
        valor=(T)Celula.CELULA_DESOCUPADA;
    }

    public Celula(int linha, int coluna, T valor) {

        this.linha = linha;
        this.coluna = coluna;
        this.valor = valor;

    }

    public Celula(int linha, int coluna) {
        this.linha = linha;
        this.coluna = coluna;
    }

    public Celula(T valor) {
        this.valor = valor;
    }

    public T getValor() {
        return valor;
    }

    public void setValor(T valor) {
        this.valor = valor;
    }

    public void setLinha(int linha) {
        this.linha = linha;
    }

    public void setColuna(int coluna) {
        this.coluna = coluna;
    }

    public int getLinha() {
        return linha;
    }

    public int getColuna() {
        return coluna;
    }

    public boolean estaLivre() {
        return valor == CELULA_DESOCUPADA;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("[célula(");
        sb.append(linha).append(",").append(coluna).append(")").append(", valor=").append(valor).append("]");

        return sb.toString();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.linha;
        hash = 67 * hash + this.coluna;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Celula<?> other = (Celula<?>) obj;
        if (this.linha != other.linha) {
            return false;
        }
        return this.coluna == other.coluna;
    }

    public static void main(String[] args) {
        System.out.println(new Celula(2, 6, null));
    }

}
