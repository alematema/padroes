package edu.undra.modelo;

import com.undra.controlador.Controlador;
import edu.undra.util.pools.CelulaPool;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author alexandre
 */
public class Grade {

    private Controlador controlador;
    private final CelulaPool pool;
    private List<Celula> celulas;
    private final int linhas;
    private final int colunas;
    
    public static int MAX_LINHAS = 100;
    public static int MAX_COLUNAS = 100;

    public Grade(int linhas, int colunas, CelulaPool pool, Controlador controlador) {
        this.linhas = linhas;
        this.colunas = colunas;
        if (pool == null) {
            throw new IllegalArgumentException("Pool não pode ser null");
        }
        this.pool = pool;
        if (controlador == null) {
            throw new IllegalArgumentException("Controlador não pode ser null");
        }
        this.controlador = controlador;
        gerarCelulas();
    }

    public Grade(int linhas, int colunas, CelulaPool pool) {
        this.pool = pool;
        this.linhas = linhas;
        this.colunas = colunas;
        gerarCelulas();
    }

    public Grade(int linhas, int colunas) {
        this.linhas = linhas;
        this.colunas = colunas;
        this.pool = null;
        gerarCelulas();
    }

    public Controlador getControlador() {
        return controlador;
    }

    public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }

    public List<Celula> getCelulas() {
        return celulas;
    }

    public Celula getCelula(int linha, int coluna) {

        if (linha < 0 || linha >= linhas || coluna < 0 || coluna >= colunas) {
            return null;//sinaliza com null qndo fora dos limites da grade
        }
        return celulas.stream()
                .parallel()
                .filter(e -> (e.getLinha() == linha && e.getColuna() == coluna))
                .findFirst()
                .get();
    }

    public Celula getCelula(int index) {

        if (index < 0 || index >= this.linhas * this.colunas) {
            return null;//ensures index bounds 
        }
        return getCelula((int) (index / linhas), index % linhas);

    }

    public Celula getCelula(Celula celula) {

        if (celula == null) {
            return null;
        }

        if (celula.getLinha() < 0 || celula.getLinha() >= linhas || celula.getColuna() < 0 || celula.getColuna() >= colunas) {
            return null;//sinaliza com null qndo fora dos limites da grade
        }
        return celulas.stream()
                .parallel()
                .filter(e -> (e.getLinha() == celula.getLinha() && e.getColuna() == celula.getColuna()))
                .findFirst()
                .get();

    }

    public <T extends Object> void setCelula(Celula cel, T valor) {
        setCelula(cel.getLinha(), cel.getColuna(), valor);
    }

    public <T extends Object> void setCelula(int linha, int coluna, T valor) {

        getCelula(linha, coluna).setValor(valor);

        controlador.atualizaView(getCelula(linha, coluna));

    }

    public int getLinhas() {
        return linhas;
    }

    public int getColunas() {
        return colunas;
    }

    private void gerarCelulas() {

        celulas = new ArrayList<>();

        for (int i = 0; i < linhas; i++) {

            for (int j = 0; j < colunas; j++) {

                Celula celula = pool.borrowObject();
                celula.setLinha(i);
                celula.setColuna(j);
                celula.setValor(Celula.CELULA_DESOCUPADA);
                celulas.add(celula);

            }
        }

    }

    public Collection<Celula> getBorda() {

        Collection<Celula> borda = new ArrayList();

        System.out.println("linha 0");
        for (int i = 0; i < getLinhas(); i++) {
            System.out.println("\t " + ((List<Celula>) getLinha(0)).get(i));
        }
        System.out.println("coluna direita " + (getColunas() - 1));
        for (int i = 0; i < getLinhas(); i++) {
            System.out.println("\t " + ((List<Celula>) getColuna(getColunas() - 1)).get(i));
        }

        System.out.println("linha inferior " + (getLinhas() - 1));
        for (int i = 0; i < getLinhas(); i++) {
            System.out.println("\t " + ((List<Celula>) getLinha(getLinhas() - 1)).get(i));
        }

        System.out.println("coluna esquerda " + "0");
        for (int i = 0; i < getLinhas(); i++) {
            System.out.println("\t " + ((List<Celula>) getColuna(0)).get(i));
        }

        borda.addAll(getLinha(0));
        borda.addAll(getColuna(getColunas() - 1));
        borda.addAll(getLinha(getLinhas() - 1));
        borda.addAll(getColuna(0));

        return borda;
    }

    public Collection<Celula> getSubBorda(int zeroBasedIndex) {

        Collection<Celula> subBorda = new ArrayList();

        /*
         
         
         x x x x x x x
         x  x x x x x
         x x x x x x x 
         x x x x x x x
         x x x x x x x
         x x x x x x x
         x x x x x x x
         
         */
        return subBorda;
    }

    public Collection<Celula> getLinha(int zeroBasedIndex) {

        if (zeroBasedIndex < 0 || zeroBasedIndex >= this.linhas) {
            throw new IllegalArgumentException("A linha não pode ser menor do que zero ou maior do que " + getLinhas());//ensures index bounds 
        }

        Collection<Celula> linha = new ArrayList();

        for (int col = 0; col < getColunas(); col++) {
            linha.add(getCelula(zeroBasedIndex, col));
        }

        return linha;

    }

    public Collection<Celula> getColuna(int zeroBasedIndex) {

        if (zeroBasedIndex < 0 || zeroBasedIndex >= this.colunas) {
            throw new IllegalArgumentException("A coluna não pode ser menor do que zero ou maior do que " + getColunas());//ensures index bounds 
        }

        Collection<Celula> coluna = new ArrayList();

        for (int linha = 0; linha < getColunas(); linha++) {
            coluna.add(getCelula(linha, zeroBasedIndex));
        }

        return coluna;

    }

    public Celula getCelulaLivre() {

        Celula celula = null;

        try {
            celula = celulas.stream()
                    
                    .filter(Celula::estaLivre)
                    .findAny()
                    .get();
        } catch (Exception e) {
        }

        return celula;

    }

    public boolean temDimensaoPar() {
        return getLinhas() % 2 == 0;
    }

    public boolean temDimensaoImpar() {
        return getLinhas() % 2 == 1;
    }

    public void retornarCelulasAoPool() {

        celulas.forEach(c -> {
            c.setValor(null);
            pool.returnObject(c);
        });

        celulas.clear();
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("grade ").append(getLinhas()).append("x").append(getColunas());
        return sb.toString();

    }

    public static void main(String[] args) {

        CelulaPool pool = new CelulaPool(3600);

        Grade grade = new Grade(8, 8, pool);

        grade.getBorda();

//        int linha = 0;
//        
//        System.out.println("linha " + linha);
//        for(Celula c : grade.getLinha(linha))System.out.println("\t" + c);
//        
//        int coluna = 0;
//        System.out.println("coluna " + coluna);
//        for(Celula c : grade.getColuna(coluna))System.out.println("\t" + c);
//        System.out.println("borda ");
//        for(int i=0;i<grade.getBorda().size();i++){{
//            
//            
//            
//            System.out.println("\t" + c);
//        }
//        for(int i=0;i<grade.getLinhas()*grade.getColunas();i++){
//            System.out.println("celula " + i + " " + grade.getCelula(i));
//        }
//        System.out.println(grade);
    }

}
