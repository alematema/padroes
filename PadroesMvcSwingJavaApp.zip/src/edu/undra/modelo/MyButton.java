package edu.undra.modelo;

import java.util.Objects;
import javax.swing.JButton;

/**
 * MyButton for fastening Jbuttons retrieval from grid view.
 * @author alexandre
 */
public class MyButton extends JButton {

    String id;
    
    @Override
    public void setName(String name) {
        super.setName(name); 
        id = name;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MyButton other = (MyButton) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }
    
    
    
}
