/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.undra.padroes;

import edu.undra.modelo.Grade;

/**
 *
 * @author alexandre
 */
public interface Padrao {
    void executar();
    void setVelocidadeExecucao(int velocidade);
    void setGrade(Grade grade);
    int getVelocidadeExecucao();
    Grade getGrade();
}
