/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.util;

import edu.undra.view.MainForm;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 *
 * @author alexandre
 */
public class ControladorGrupoDeBotoes {

    private List<JButton> botoes;

    private MainForm mainForm;

    public ControladorGrupoDeBotoes() {
        botoes = new ArrayList();
    }

    public ControladorGrupoDeBotoes(MainForm mainForm) {
        this();
        this.mainForm = mainForm;
    }

    public void registrarBotao(JButton botao) {
        if (botao == null) {
            throw new IllegalArgumentException("O botao não pode ser null");
        }
        botoes.add(botao);
    }

    public void desregistrarBotao(JButton botao) {
        if (botao == null) {
            throw new IllegalArgumentException("O botao não pode ser null");
        }
        botoes.remove(botao);
    }

    public void destacarBotao(JButton botao) {
       
        if (botao == null) {
            throw new IllegalArgumentException("O botao não pode ser null");
        }
        
        botoes.forEach(e -> e.setEnabled(false));
        
        botao.setText("");
        
        Image image;

        String imgName = mainForm.getGroupButtonBackGroundImageName();

        image = new javax.swing.ImageIcon(ControllerHelper.class.getResource(imgName)).getImage();

        botao.setDisabledIcon(new ImageIcon(image.getScaledInstance(botao.getWidth(), botao.getHeight(), java.awt.Image.SCALE_FAST)));
    }

    public void desdestacarBotao(JButton botao, String text) {
        if (botao == null) {
            throw new IllegalArgumentException("O botao não pode ser null");
        }
        botoes.forEach(e -> e.setEnabled(true));
        botao.setIcon(null);
        botao.setDisabledIcon(null);
        botao.setText(text);
        
    }

    public List<JButton> getBotoes() {
        return botoes;
    }

    public void setBotoes(List<JButton> botoes) {
        this.botoes = botoes;
    }
    
}
