/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.util;

import edu.undra.util.pools.CelulaPool;
import com.undra.controlador.Controlador;
import edu.undra.modelo.Celula;
import edu.undra.modelo.Grade;
import edu.undra.util.pools.ImagePool;
import edu.undra.view.MainForm;
import java.awt.Image;
import java.beans.PropertyChangeListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 *
 * @author alexandre
 */
public class ControllerHelper {

    private static MainForm mainForm;

    private static CelulaPool celulaPool = new CelulaPool(10000);
    private static ImagePool imagePool;

    public static ImagePool getImagePool() {
        return imagePool;
    }

    public static void setImagePool(ImagePool imagePool) {
        ControllerHelper.imagePool = imagePool;
    }

    public static CelulaPool getCelulaPool() {
        return celulaPool;
    }

    public static void setCelulaPool(CelulaPool celulaPool) {
        ControllerHelper.celulaPool = celulaPool;
    }
    
    public static void addPropertyChangeListenerToMainView(PropertyChangeListener changeListener) {
        mainForm.addPropertyChangeListener(changeListener);
    }

    static public void setMainForm(MainForm view) {
        mainForm = view;
    }

    public static void atualizaMainView(Celula celula, MainForm mainForm) {

        JButton button = mainForm.getBotao(celula.getLinha(), celula.getColuna());

        if (celula.getValor().equals(Celula.CELULA_DESOCUPADA)) {
            
            imagePool.returnObject((ImageIcon) button.getIcon());
            button.setIcon(null);
            
        } else {//célula ocupada
            
            ImageIcon icon = imagePool.borrowObject();
            Image image = icon.getImage();

            icon.setImage(image.getScaledInstance(button.getWidth(), button.getHeight(), java.awt.Image.SCALE_FAST));

            button.setIcon(icon);
        }

    }

    public static String getGridButtonBackGroundImagePathAndName() {
        return mainForm.getGridButtonBackGroundImagePathAndName();
    }

    public static Grade createGrade(int n, Controlador controlador) {
        if (controlador == null) {
            throw new IllegalArgumentException("O controlador não pode ser null");
        }
        Grade grade = new Grade(n, n, celulaPool);
        grade.setControlador(controlador);
        return grade;
    }

}
