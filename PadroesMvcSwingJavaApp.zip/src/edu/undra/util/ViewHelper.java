/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.util;

import edu.undra.algoritmos.PadraoCaracol;
import edu.undra.modelo.Grade;
import edu.undra.padroes.ExecutorDePadrao;
import edu.undra.padroes.Padrao;
import edu.undra.util.pools.ImagePool;
import edu.undra.view.MainForm;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingWorker;

/**
 *
 * @author alexandre
 */
public class ViewHelper {

    private static MainForm mainForm;

    private static ImagePool imgPool;

    public static MainForm getMainForm() {
        return mainForm;
    }

    public static void setMainForm(MainForm mainForm) {
        ViewHelper.mainForm = mainForm;
    }

    public static ImagePool getImgPool() {
        return imgPool;
    }

    public static void setImgPool(ImagePool imgPool) {
        ViewHelper.imgPool = imgPool;
    }

    public static void executarPadrao(Padrao padrao, JButton botaoClicado, String buttonText) {

        if (padrao instanceof PadraoCaracol) {//o algoritmo de caracol só está implementado para valores impares. por isso esse teste aqui
            int tamanhoGrade = mainForm.getjSliderTamanhoGrade().getValue();
            if (tamanhoGrade % 2 == 0) {
                mainForm.getjSliderTamanhoGrade().setValue(tamanhoGrade + 1);
            }
            if (tamanhoGrade >= Grade.MAX_LINHAS) {
                mainForm.getjSliderTamanhoGrade().setValue(99);
            }
        }

        padrao.setVelocidadeExecucao(mainForm.getjSliderVelocidadeExecucaoPadrao().getValue());
        padrao.setGrade(ControllerHelper.createGrade(mainForm.getjSliderTamanhoGrade().getValue(), mainForm.getControlador()));

        mainForm.setPadrao(padrao);

        mainForm.getControladorGrupoBotoes().destacarBotao(botaoClicado);//destaca o botao clicado pelo usuario e desabilita os outros
        mainForm.getjSliderTamanhoGrade().setEnabled(false);
        mainForm.getjLabelTamanhoGrado().setEnabled(false);


        SwingWorker worker = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {

                ExecutorDePadrao.executar(padrao);

                Thread.sleep(700);
                
                gerarGradeDaView(mainForm.getjSliderTamanhoGrade().getValue());

                mainForm.getjSliderTamanhoGrade().setEnabled(true);
                mainForm.getjLabelTamanhoGrado().setEnabled(true);
                mainForm.getControladorGrupoBotoes().desdestacarBotao(botaoClicado, buttonText);//habilita todos botoes

                return null;
            }
        };

        worker.execute();

    }

    public static void paintButton(JButton b, String iconPath) {

        Image image;

        image = new javax.swing.ImageIcon(ControllerHelper.class.getResource(iconPath)).getImage();

        b.setIcon(new ImageIcon(image.getScaledInstance(b.getWidth() == 0 ? 1 : b.getWidth(), b.getHeight() == 0 ? 1 : b.getHeight(), java.awt.Image.SCALE_FAST)));
    }

    static public Grade getGrade(int n) {

        Grade grade = null;

        return grade;

    }

    static public void returnImageToPool(ImageIcon icon) {

        imgPool.returnObject(icon);

    }

    static public void gerarGradeDaView(int n) {

        //retorna botoes e imagens pros pools
        mainForm.getBotoes().forEach((JButton botao) -> {
            returnImageToPool((ImageIcon) botao.getIcon());
            botao.setIcon(null);
            mainForm.getButtonPool().returnObject(botao);
        });
        
        mainForm.getBotoes().clear();

        mainForm.getjPanelGrade().removeAll();

        mainForm.getjPanelGrade().setLayout(new GridLayout(n, n));
        mainForm.getjPanelSlidersPadroes().setBorder(javax.swing.BorderFactory.createTitledBorder(null, "  padrões", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 0, 12), new java.awt.Color(1, 1, 1))); // NOI18N

        mainForm.getjPanelGrade().setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black, 1, true),Integer.toString(n) + " x " + Integer.toString(n) + " = " + n * n + " pontos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 12), new java.awt.Color(1, 1, 1)));

        for (int i = 0, j = 0;
                i < n * n;
                i++) {

            JButton button = mainForm.getButtonPool().borrowObject();

            button.setName(Integer.toString(i / n) + "," + Integer.toString(j));

            button.setOpaque(false);
            button.setDoubleBuffered(true);

            button.setBackground((mainForm.getBackgroundBotoesGrade()).brighter());

            button.paintImmediately(button.getBounds());

            mainForm.getBotoes().add(button);
            mainForm.getjPanelGrade().add(button);

            j++;
            if (j % n == 0) {
                j = 0;
            }

        }

        mainForm.getjPanelGrade().paintImmediately(mainForm.getjPanelGrade().getBounds());
        mainForm.getjPanelGrade().updateUI();

    }

}
