/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.undra.util.pools;

import edu.undra.util.Timer;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;

/**
 *
 * @author alexandre
 */
public class ButtonPool extends Pool<JButton>{

    public ButtonPool() {
        super(3600);
    }
    
    public ButtonPool(int MIN_SIZE) {
        super(MIN_SIZE);
    }
        
    
    @Override
    protected JButton createObject() {
        JButton b = new JButton();
//        ViewHelper.paintButton(b, ControllerHelper.getGridButtonBackGroundImagePathAndName());
        return b;
    }
    
    public static void main(String[] args) {
        
        Runnable code;
        
        //Timeit.timeCode(timeCode);
        
        code = () -> {
            
            List l = new ArrayList();
            ButtonPool pool = new ButtonPool();
            
            System.out.println("pool size " + pool.getSize());
            
            for(int i=0;i<3600;i++){
                l.add(pool.borrowObject());
            }
            System.out.println("pool size " + pool.getSize());
           
            pool.returnObject(pool.borrowObject());
            
            System.out.println("pool size " + pool.getSize());
            
            for(int i=0;i<3600;i++){
                pool.returnObject((JButton)l.get(i));
            }
            
            System.out.println("pool size " + pool.getSize());
            
        };
        
        Timer.timeCode(code);
        
    }

}
