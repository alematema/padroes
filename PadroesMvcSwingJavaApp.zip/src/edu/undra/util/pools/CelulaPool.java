/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.undra.util.pools;

import edu.undra.modelo.Celula;

/**
 *
 * @author alexandre
 */
public class CelulaPool extends Pool<Celula>{

    public CelulaPool(int MIN_SIZE) {
        super(MIN_SIZE);
    }

    @Override
    protected Celula createObject() {
        return new Celula();
    }

}
