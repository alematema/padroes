/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.util.pools;

import edu.undra.view.MainForm;
import java.util.LinkedList;
import javax.swing.ImageIcon;

/**
 *
 * @author alexandre
 */
public final class ImagePool extends Pool<ImageIcon> {

    private MainForm mainForm;

    public ImagePool(int MIN_SIZE) {
        super(MIN_SIZE);
    }

    public ImagePool(MainForm mainForm, int MIN_SIZE) {
        
        super(mainForm,MIN_SIZE);
        this.mainForm = mainForm;
        
        pool = new LinkedList<>();
        for(int i=0; i<MIN_SIZE;i++){
            boolean add = pool.add(createObject());
        }
        
    }

    @Override
    protected ImageIcon createObject() {
        
        String imgName = mainForm.getGridButtonBackGroundImagePathAndName();
        return new javax.swing.ImageIcon(ImagePool.class.getResource(imgName));

    }

}
