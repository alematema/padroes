/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.undra.util.pools;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author alexandre
 * @param <T>
 */
public abstract class Pool<T> {
    
    protected int MIN_SIZE;
    
    Queue<T> pool;

    public Pool(int MIN_SIZE) {
        initialize(MIN_SIZE);
    }
    
    public Pool(Object o, int MIN_SIZE){
        this.MIN_SIZE = MIN_SIZE;
    }
    
    public T borrowObject(){
       T object  = pool.poll();
       if(object == null){
           object = createObject();
       }
       return object;
    }
    
    public void returnObject(T object){
         if(object==null)return;
         pool.offer(object);
    }
    
    private void initialize(int MIN_SIZE) {
        pool = new LinkedList<>();
        for(int i=0; i<MIN_SIZE;i++){
            pool.add(createObject());
        }
    }
    
    public int getSize(){
        return pool.size();
    }
    
    protected abstract T createObject();

}
