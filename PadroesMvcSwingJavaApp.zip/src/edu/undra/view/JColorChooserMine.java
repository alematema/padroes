/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.undra.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JPanel;

/**
 *
 * @author alexandre
 */
public class JColorChooserMine extends JColorChooser {

    public static JPanel createPanel(JColorChooser chooserPane, ActionListener okListener,
            ActionListener cancelListener) {

         JPanel panel = initColorChooserPanel(chooserPane, okListener, cancelListener);

        return panel;
    }

    static protected JPanel initColorChooserPanel(JColorChooser chooserPane,
            ActionListener okListener, ActionListener cancelListener) {

        String okString = "OK";
        String cancelString = "Cancela";
        String resetString = "Reseta";

        JPanel contentPane = new  JPanel();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(chooserPane, BorderLayout.CENTER);

        /*
         * Create Lower button panel
         */
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
        JButton okButton = new JButton(okString);
        okButton.getAccessibleContext().setAccessibleDescription(okString);
        okButton.setActionCommand("OK");
        okButton.addActionListener((e) -> {
            
        });
        if (okListener != null) {
            okButton.addActionListener(okListener);
        }
        buttonPane.add(okButton);

        JButton cancelButton = new JButton(cancelString);
        cancelButton.getAccessibleContext().setAccessibleDescription(cancelString);
        cancelButton.setActionCommand("cancel");

        if (cancelListener != null) {
            cancelButton.addActionListener(cancelListener);
        }
//        buttonPane.add(cancelButton);

        JButton resetButton = new JButton(resetString);
        resetButton.getAccessibleContext().setAccessibleDescription(resetString);

        resetButton.addActionListener((ActionEvent e) -> {
            chooserPane.setColor(Color.yellow);
        });
        
        buttonPane.add(resetButton);
        
        
        contentPane.add(buttonPane, BorderLayout.SOUTH);

        return contentPane;

    }

}
